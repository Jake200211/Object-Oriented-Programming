/*
Author: Jacob Almeida
Date: 02-04-2019
*/

class ProgrammingExercise10_3 {
	public static void main(String[] args) {
		MyInteger a1 = new MyInteger(7);
		
		System.out.println("Testing isEven functions:");
		System.out.println(MyInteger.isEven(6));
		System.out.println(MyInteger.isEven(new MyInteger(12)));
		System.out.println(MyInteger.isEven(5));
		System.out.println(" ");
		
		System.out.println("Testing isOdd functions:");
		System.out.println(MyInteger.isOdd(12));
		System.out.println(MyInteger.isOdd(new MyInteger(15)));
		System.out.println(MyInteger.isOdd(9));
		System.out.println(" ");
		
		System.out.println("Testing isPrime functions:");
		System.out.println(MyInteger.isPrime(11));
		System.out.println(MyInteger.isPrime(new MyInteger(34)));
		System.out.println(" ");
		
	}
}